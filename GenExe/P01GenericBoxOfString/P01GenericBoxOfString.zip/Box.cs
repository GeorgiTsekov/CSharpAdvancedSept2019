﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace P01GenericBoxOfString
{
    public class Box<T> 
        where T : IComparable<T>
    {
        private List<T> boxCollection;

        public Box()
        {
            this.boxCollection = new List<T>();
        }

        public void Add(T item)
        {
            boxCollection.Add(item);
        }

        public void CountBiggerThenBoxColl(T input)
        {
            //input.CompareTo()
            //int inputToAsCcIii = input
            //    .ToString()
            //    .Select(x => (int)x)
            //    .Sum();

            boxCollection = boxCollection.Where(x => x.CompareTo(input) == 1).ToList();

            //boxCollection = boxCollection
            //    .Where(x => x.ToString()
            //    .Select(y => (int)y)
            //    .Sum() > inputToAsCcIii).ToList();
        }

        public override string ToString()
        {
            return boxCollection.Count.ToString().TrimEnd();
        }
    }
}
